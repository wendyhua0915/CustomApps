//
//  CameraViewController.swift
//  CustomApp
//
//  Created by wendy hua on 4/18/18.
//  Copyright © 2018 wendy hua. All rights reserved.
//

import Foundation
import UIKit

class CameraViewController : UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
