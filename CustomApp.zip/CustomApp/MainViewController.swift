//
//  MainViewController.swift
//  CustomApp
//
//  Created by Maxson Yang on 4/23/18.
//  Copyright © 2018 wendy hua. All rights reserved.
//

import Foundation
import UIKit

public class MainViewController {
    
    
    
    
}
